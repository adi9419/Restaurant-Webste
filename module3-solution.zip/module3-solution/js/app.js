// Toggles the mobile dropdown menu open/closed when the
// hamburger button in the navbar is clicked.
document.addEventListener('DOMContentLoaded', function () {
  var toggleButton = document.getElementById('menuToggle');
  var mobileMenu = document.getElementById('mobileMenu');

  toggleButton.addEventListener('click', function () {
    mobileMenu.classList.toggle('open');
  });
});
